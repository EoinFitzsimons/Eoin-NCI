/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package undevelopment.IntegrationsFolder;

/**
 *
 * @author dmoc2
 */
public class choiceCardHolder {
    
    public void card1()
    {
        undevelopment.IntegrationsUI.cardHolderImg.setText("Please pick from button 1, 2 or 3 as a test please");
        
        
    }
    
    public void choices1()
    {
         undevelopment.IntegrationsUI.choiceOneBTN.setText("I'm the right answer!");
    }
    
    public void choices1a ()
    {
        undevelopment.IntegrationsUI.choiceTwoBTN.setText("I'm the wrong answer!");
    }
    
    public void choices1b()
    {
        undevelopment.IntegrationsUI.choiceThreeBTN.setText("I'm the wrong answer!");
    }
    
    
    
    
    
}
