/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package undevelopment;

/**
 *
 * @author Aepel
 */
public class FactsAboutSids {
String sidscountry;
String sidsfact;
  

    public FactsAboutSids(String sidscountry, String sidsfact) {
        this.sidscountry = sidscountry;
        this.sidsfact = sidsfact;
    }

    public String getSidscountry() {
        return sidscountry;
    }

    public void setSidscountry(String sidscountry) {
        this.sidscountry = sidscountry;
    }

    public String getSidsfact() {
        return sidsfact;
    }

    public void setSidsfact(String sidsfact) {
        this.sidsfact = sidsfact;
    }
    
    
}
