# Climate Action Quizzes
OOP-NCI-GroupH
Group H for National College of Ireland Java Object Orientated Programming Module.

Our task is to build a prototype of an application which would support the achievement of one of the UN SDGs. • Working in teams of 3 people you will build a fully functional prototype for your app using java • The app must consist of 3 distinct sections • Each member of the team will take responsibility for the development of one of these sections • All sections should then be combined into one complete seamless package • Each section should contain: • More than 3 classes • 3 or more distinct functions or features • Data input and output • Dynamic interfaces using text and images • More than 1 form requiring user input

Project Proposal

The idea is to have an app that spreads information on climate action which is goal thirteen. We will be going about this in a fun way, using quizzes, hangman, and other word games.

Section Zero - Eoin, David, Conor - Application / Links to individual applications

Section One - Eoin Fitzsimons - Crossword

Section Two - David O Connor -

Section Three - Conor Judge -

Section Four - Aaron Eppelbaum



Style Choices

Colours: Red (#dc143c)  and Blue (#caf2fb) and Green (#98c12a)
Fonts: Lobster and Sarabun
Aspect Ratio: Default
